package com.Mike.Proj.dto;

public class ResponseDto {
    
    private String response;
    private String message;
    
    public ResponseDto(String response, String message) {
        this.response = response;
        this.message = message;
    }

    /**
     * @return String return the response
     */
    public String getResponse() {
        return response;
    }

    /**
     * @param response the response to set
     */
    public void setResponse(String response) {
        this.response = response;
    }

    /**
     * @return String return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
