package com.Mike.Proj.exceptions;

public class CustomException extends IllegalArgumentException {

    public CustomException(String message) {
       super(message);
    }
}
