<template>
  <div id="home">
    <div class="" id="background-div">
            <!-- <img src="../assets/home.jpg" class="w-100 img-fluid" alt=""> -->
    </div>
     <div class="container p-5 text-center about-us col-sm-10">
        <div class="row">
          <h1 class="display-6">About Us</h1>
          <h4 class="mb-5">Royalty Car Rental <br><br></h4>
          <p class="text-start mt-5" style="font-size: large;">Our vision is to become the most customer centric company in car rental industry. We will be persistent in building strong relationships with our customers and business partners.<br><br>
              We will be constantly focusing on innovation and delivery of simple high-quality service to our customers. <br><br>
              We are convinced that we need to innovate and control the high technology behind our services, and to participate only in markets where we can make significant contribution. <br><br>
              We don’t settle for anything less than excellence in every branch office and group in the company. We have courage to admit when and if we are wrong and courage to change. <br><br>
              We strive to create local opportunity, competitive advantage growth, and impact in every branch office around the World. <br><br>
              Our strategy is to build best-in-class IT platforms which will enable us to be productive and to deliver carefully customized services.
          </p>
        </div>
     </div>
     
      <!-- sections -->
      <div class="nav-pills nav-fill mt-3" id="nav">
          <!-- our values dropdown -->
        <section class="nav-item text-start">
          <a class="nav-link page-sections active sticky-top" type="button"
              data-toggle="collapse" aria-label="Toggle navigation"
                  aria-expanded="true" data-target="ourValues"
                  aria-controls="ourValues" id="ourValuesBtn">
                  01 Our Values
          </a>
          <div class="row g-0" id="ourValues" aria-labelledby="ourValuesBtn">
            <div class="col-md-6 text-white section-text">
              <div class="container-fluid pe-xl-0 h-100">
                <div class="d-flex flex-column justify-content-center align-items-start max-w-500 h-100 mx-auto ms-lg-0 me-lg-auto px-3 px-lg-3 py-5 py-xl-0">
                  <h2 class="">Our Values</h2>
                  <p>We always place the interests of our customers first. We always conduct business with implementation of high
                    standards, trust, honesty, professionalism and ethical behaviour.
                  </p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <img src="../assets/ceo1.jpg" class="img-fluid max-h-100-vh" alt="...">
            </div>
            <!-- <div class="row p-5 mx-0"></div> -->
            <div class="row g-0 p-5 section-description-text">
              <div class="col-lg-5 d-flex">
                <img src="../assets/ceo2.jpg" class="img-fluid max-h-100-vh" alt="...">
              </div>
              <div class="col-lg-7">
                <div class="container-fluid pe-xl-0 h-100">
                  <div class="d-flex flex-column justify-content-center align-items-start max-w-500 h-100 mx-auto ms-lg-0 me-lg-auto px-3 px-lg-3 py-5 pt-1 py-xl-0">
                    <h1 class="p-0 m-0" style="font-size: 80px;">,,</h1>
                    <p>Talent is the No. 1 priority for a CEO. You think it's about vision and strategy, but you have to get the
                        right people first. Trustworthiness, honesty and reliability are the keystone values of Royalty Car Rental.
                        We are entirely committed to creating fully-cusomized service at the right price, whether it is for an
                        individual or a company's needs. It's as simple as that - we are the brand you can trust. <br><br>
                        <strong>Brian Langsoni</strong><br>CEO - Royalty Car Rental
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

          <!-- our vision dropdown -->
        <div class="nav-item text-start">
          <a class="nav-link page-sections sticky-top active" type="button"
              data-toggle="collapse" aria-label="Toggle-navigation"
                aria-expanded="true" data-target="ourVision"
                  aria-controls="ourVision">
                  02 Our Vision
          </a>
          <div class="row g-0" id="ourVision">
            <div class="col-md-6 text-white section-text">
              <div class="container-fluid pe-xl-0 h-100">
                <div class="d-flex flex-column justify-content-center align-items-start max-w-500 h-100 mx-auto ms-lg-0 me-lg-auto px-3 px-lg-3 py-5 py-xl-0">
                  <h2 class="">Our Vision</h2>
                  <p>Our Vision is to become one of the leading brands in the rental industry
                      of Africa and to build the wide network of branches in the World
                  </p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <img src="../assets/our-vision.jpg" class="img-fluid max-h-100-vh" alt="...">
            </div>
          </div>
        </div>

        <!-- Our know-how dropdown -->
        <div class="nav-item text-start">
          <a class="nav-link page-sections sticky-top active" type="button"
              data-toggle="collapse" aria-label="Toggle-navigation"
                aria-expanded="true" data-target="ourKnowHow"
                  aria-controls="ourKnowHow">
                  03 Our Know-How
          </a>
          <div class="row g-0" id="ourKnowHow">
            <div class="col-md-6 d-flex">
              <img src="../assets/AppImages/demio.jpg" class="img-fluid max-h-100-vh" alt="...">
            </div>
            <div class="col-md-6 text-white section-text">
              <div class="container-fluid pe-xl-0 h-100">
                <div class="d-flex flex-column justify-content-center align-items-start max-w-500 h-100 mx-auto ms-lg-0 me-lg-auto px-3 px-lg-3 py-5 py-xl-0">
                  <h2 class="">Our Know-How</h2>
                  <p>Royalty Car Rental brand was founded by Braso Communications, a renowned world-class telecommunications and
                      marketing company from Zimbabwe. During the last decade Brasco Communications has worked well with many globally
                      well-known companies around Europe, North America and Africa.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12 section-description-text">
            <p class="p-5 m-0">As a result, we've driven over $300 000 in sales and over 1 million leads for our businesses and clients. BRASCO Communications
              is a premier reputation film active in Harare, Melbourne and Dubai that specializes in printing, digital marketing, SEO activities,
              web design, and data to drive targeted visibility and engagement that builds brand reputation and delivers profit growth.
              <br><br>
              We've been in business in more than 5 countiries, and our portfolio uncludes such clients as Pizza Hut, Chicken Matty, Seasons
              Pharmaceuticals, Ministry of Health, ZAOGA FIF, etc.
              <br><br>
              Likewise, we know that hitting these goals moves businesses forward, and we believe that our client's success is the best
              measure of our performance.
              <br><br>
              Our Team is made up of award-winning marketers, business consultants, professors, designers, and developers, and we know what
              it takes to get real results online.
            </p>
          </div>
        </div>

        <!-- Our Locations dropdown -->
        <div class="nav-item text-start">
          <a class="nav-link page-sections sticky-top active" type="button"
              data-toggle="collapse" aria-label="Toggle-navigation"
                aria-expanded="true" data-target="ourLocation"
                  aria-controls="ourLocation">
                  04 Our Locations
          </a>
          <div class="row g-0" id="ourLocation">
            <div class="col-md-6 text-white section-text">
              <div class="container-fluid pe-xl-0 h-100">
                <div class="d-flex flex-column justify-content-center align-items-start max-w-500 h-100 mx-auto ms-lg-0 me-lg-auto px-3 px-lg-3 py-5 py-xl-0">
                  <h2 class="">Our Locations</h2>
                  <p>We are a premium car rental group in Africa, Australia and the Middle East. It doesn't matter where you are located,
                      there will always be a convenient Royalty car rental branch nearby to help you continue your journery.
                  </p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <img src="../assets/locations.jpg" class="img-fluid max-h-100-vh" alt="...">
            </div>
          </div>
          <div class="col-12 map-container w-100 bg-light-gray py-4 px-3 py-lg-9">
            <img src="../assets/map-main.png" class="img-fluid max-h-100-vh" title="Royal Car Rental">
            <div class="px-3 px-lg-0 map-stats d-flex flex-column flex-sm-row justify-content-evenly align-items-center mt-4">
              <div class="d-flex flex-column justify-content-center align-items-center mb-4">
                <span class="lh-1 mb-2 display-4 text-warning">
                    1
                </span>

                <span>
                    year operating
                </span>
              </div>
              <div class="d-flex flex-column justify-content-center align-items-center mb-4">
                <span class="lh-1 mb-2 display-4 text-warning">
                    6
                </span>
                <span>
                    countries
                </span>
              </div>
              <div class="d-flex flex-column justify-content-center align-items-center mb-4">
                <span class="lh-1 mb-2 display-4 text-warning">
                    7
                </span>
                <span>
                    branch offices
                </span>
              </div>
            </div>
          </div>
        </div>

        <!-- Our Fleets dropdown -->
        <div class="nav-item text-start">
          <a class="nav-link page-sections sticky-top active" type="button"
              data-toggle="collapse" aria-label="Toggle-navigation"
                aria-expanded="false" data-target="ourFleets"
                  aria-controls="ourFleets">
                  05 Our Fleets
          </a>
          <div class="row g-0" id="ourFleets">
            <div class="col-md-7 text-white section-text">
              <div class="container-fluid pe-xl-0 h-100">
                <div class="d-flex flex-column justify-content-center align-items-start max-w-500 h-100 mx-auto ms-lg-0 me-lg-auto px-3 px-lg-3 py-5 py-xl-0">
                  <h2 class="">Our Fleets</h2>
                  <p>You've got the drive to travel in luxury, and we've got the tools, know-how and knowledge to help you take charge
                      of your travel. Lets get you started on the path to your very own Royalty car rental hire.
                  </p>
                </div>
              </div>
            </div>
            <div class="col-md-5">
              <img src="../../public/logo-square.jpg" class="img-fluid max-h-100-vh" alt="...">
            </div>
          </div>
        </div>
      </div>
      <!-- <iframe src="https://maps.google.com/maps?q=35.856737, 10.606619&z=15&output=embed" width="360" height="270" frameborder="0" style="border:0"></iframe> -->



    <!--    display categories-->
    <div class="container">
    <div class="row">
          <div class="col-12 text-center">
            <h2 class="pt-3 mt-4"> Top Categories</h2>
          </div>
        </div>
        <div class="row justify-content-evenly">
          <div v-for="index in this.categorySize" :key="index"
               class="col-md-6 col-xl-4 col-12 pt-3 my-2 justify-content-around">
            <CategoryBox :category="categories[index-1]" />
          </div>
        </div>
      </div>

   <!--    display Products-->
    <div class="container py-4">
        <div class="row">
          <div class="col-12 text-center">
            <h2 class="pt-3 pb-3">Top Vehicles</h2>
          </div>
        </div>
        <div class="row justify-content-evenly">
          <div v-for="index in this.productSize" :key="index"
            class="col-md-6 col-xl-4 col-12 pt-3 my-2 justify-content-around">
            <ProductBox :product="products[index-1]"/>
          </div>
        </div>
      </div>

  
  </div>
</template>

<script>
import CategoryBox from "../components/Category/CategoryBox.vue";
import ProductBox from "@/components/ProductBox.vue";

export default {
  name: "HomeView",
  components: {CategoryBox, ProductBox},
  props: ["categories", "products"],
  data() {
    return {
      categorySize: 0,
      productSize: 0
    }
  },
  methods:{
    scrollPositions(){
    }
  },
  mounted() {
    this.categorySize = Math.min(6, this.categories.length );
    this.productSize = Math.min(8, this.products.length);
    // this.scrollPositions();
  }
};
</script>


<style scoped>

#background-div {
  margin-top: -55px;
  background: url("../assets/home.jpg");
  background-size: cover !important;
  min-height: 90vh;
}
.section-text{
  background-color: #090051;
}
.section-description-text{
  background-color: rgba(255, 253, 208, 0.85);
}
.section-text p{
  font-size: large;
}
.img-fluid{
  object-fit: cover;
}
.map-stats {
  position: relative;
}
  #home{
    background-color: rgb(241, 241, 241);
  }
  #heading {
    font-weight: 400;
  }
  .about-us{
  margin-top: -180px;
  margin-bottom: 2rem;
  background-color: rgba(201, 201, 201, 0.85); /* Creamy color with 92.5% opacity */
  /* transition: all 1s ease-in-out 0s; */
}
  div{
    transition: all 1s ease-in-out 0s;
  }
  .sticky-top{
    top: 120px;
  }
  .page-sections{
    border-radius: 0;
    display: flex;
    justify-content: center;
    padding: 16px;
  }
  .page-sections:hover{
    cursor: default;
  }
  @media (min-width: 0px) and (max-width: 992px) {
    div.about-us{
      margin-top: 2rem;
    }
  }
</style>