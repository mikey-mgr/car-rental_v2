<template>
    <div class="row text-center mt-3">
        <h1>Failed</h1>
    </div>
</template>

<script>
export default {
    name: 'StripeFailed',
}
</script>