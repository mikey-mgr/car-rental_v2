<template>
    <div class="p-4 text-bg-success w-100" style="margin-top: -14px;">
        <div class="row">
            <h1>This is a contact us page</h1>
        </div>
    </div>
</template>

<script>
export default {
    name: 'ContactUs',
}
</script>

<style scoped>

</style>